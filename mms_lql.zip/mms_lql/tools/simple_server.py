# -*- coding: utf-8 -*-
"""
智能储物柜简易TCP服务器
STM32通过ESP8266连接此服务器，实现远程控制

使用方法：
1. 运行此脚本: python simple_server.py
2. 修改STM32代码中的 TCP_SERVER_IP 为本机IP
3. STM32连接WiFi后会自动连接此服务器
"""
import socket
import threading
import time

# 配置
HOST = '0.0.0.0'  # 监听所有网卡
PORT = 8888       # 端口号（与STM32代码中TCP_SERVER_PORT一致）

# 已连接的设备
device_conn = None
device_addr = None
device_lock = threading.Lock()

def handle_device(conn, addr):
    """处理设备连接"""
    global device_conn, device_addr
    
    with device_lock:
        device_conn = conn
        device_addr = addr
    
    print(f"\n[设备] 已连接: {addr}")
    print("[提示] 现在可以发送控制命令了")
    
    try:
        while True:
            data = conn.recv(1024)
            if not data:
                break
            msg = data.decode('utf-8').strip()
            
            # 解析设备消息
            if msg.startswith("STATUS:"):
                status = msg[7:]
                print(f"[状态上报] 锁状态: {status}")
            elif msg.startswith("UNLOCK:"):
                result = msg[7:]
                if result == "OK":
                    print("[开锁结果] OK 开锁成功!")
                elif result == "FAIL":
                    print("[开锁结果] X 开锁失败!")
                elif result == "LOCKED":
                    print("[开锁结果] X 系统已锁定，无法开锁")
            else:
                print(f"[设备消息] {msg}")
                
    except Exception as e:
        print(f"[错误] {e}")
    finally:
        print(f"\n[设备] 断开连接: {addr}")
        with device_lock:
            device_conn = None
            device_addr = None
        conn.close()

def send_to_device(cmd):
    """发送指令到设备"""
    global device_conn
    
    with device_lock:
        if device_conn:
            try:
                device_conn.send((cmd + "\n").encode('utf-8'))
                print(f"[发送] {cmd}")
                return True
            except:
                print("[错误] 发送失败，设备可能已断开")
                return False
        else:
            print("[错误] 设备未连接")
            return False

def server_thread():
    """服务器线程"""
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(1)
    print(f"[服务器] 启动成功，监听端口 {PORT}")
    print(f"[服务器] 等待STM32设备连接...")
    
    while True:
        conn, addr = server.accept()
        t = threading.Thread(target=handle_device, args=(conn, addr))
        t.daemon = True
        t.start()

# 获取本机IP
def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "未知"

# 启动服务器
t = threading.Thread(target=server_thread)
t.daemon = True
t.start()

local_ip = get_local_ip()

print("="*50)
print("智能储物柜 - TCP控制服务器")
print("="*50)
print(f"本机IP: {local_ip}")
print(f"端口: {PORT}")
print("="*50)
print("请在STM32代码 main.c 中设置:")
print(f'  #define TCP_SERVER_IP   "{local_ip}"')
print(f'  #define TCP_SERVER_PORT "{PORT}"')
print("="*50)

# 控制菜单
try:
    while True:
        print("\n--- 控制菜单 ---")
        print("1. 远程开锁")
        print("2. 查询状态")
        print("3. 查看连接状态")
        print("0. 退出")
        
        choice = input("选择: ").strip()
        
        if choice == '1':
            send_to_device("CMD:UNLOCK")
        elif choice == '2':
            send_to_device("CMD:STATUS")
        elif choice == '3':
            with device_lock:
                if device_conn:
                    print(f"OK 设备已连接: {device_addr}")
                else:
                    print("X 无设备连接")
        elif choice == '0':
            print("退出程序")
            break
        else:
            print("无效选择")
            
except KeyboardInterrupt:
    print("\n程序被中断")
