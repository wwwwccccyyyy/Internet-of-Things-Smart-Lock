/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body - WiFi Scanner with Keypad Input
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "OLED.h"
#include "esp8266.h"
#include "KEY.h"
#include "feedback.h"
#include "lock.h"
#include "at24c02.h"
#include <string.h>
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define MAX_PWD_LEN      20
#define LOCK_PWD_LEN     6
#define DEFAULT_LOCK_PWD "123456"

/* 菜单项数量 */
#define MENU_ITEMS  3

/* EEPROM存储地址定义 */
#define EEPROM_ADDR_FLAG     0x00    /* 标志位地址（0x5A表示已初始化） */
#define EEPROM_ADDR_PWD      0x01    /* 密码存储起始地址（6字节） */
#define EEPROM_FLAG_INIT     0x5A    /* 初始化标志 */

/* 密码错误锁定参数 */
#define PWD_ERROR_MAX        3       /* 最大连续错误次数 */
#define PWD_LOCKOUT_TIME     300     /* 锁定时间（秒），5分钟 */

/* TCP服务器配置 - 修改为你电脑的IP地址 */
#define TCP_SERVER_IP        "192.168.80.57"
#define TCP_SERVER_PORT      "8888"
#define TCP_CHECK_INTERVAL   100     /* TCP数据检查间隔（ms） */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
char g_ssid_list[WIFI_MAX_NUM][WIFI_SSID_MAX_LEN];  /* 6个WiFi，每个17字节 */
uint8_t g_wifi_count = 0;
uint8_t g_select_idx = 0;
char g_password[MAX_PWD_LEN];
uint8_t g_pwd_len = 0;
uint8_t g_wifi_connected = 0;  /* WiFi连接状态标志：0=未连接，1=已连接 */

/* 开锁密码相关 */
char g_lock_pwd[LOCK_PWD_LEN + 1] = DEFAULT_LOCK_PWD;  /* 开锁密码，初始123456 */
char g_input_pwd[LOCK_PWD_LEN + 1];  /* 输入的密码 */
uint8_t g_input_len = 0;  /* 已输入密码长度 */

/* 密码错误锁定相关 */
uint8_t g_pwd_error_cnt = 0;         /* 连续错误次数 */
uint8_t g_pwd_locked = 0;            /* 锁定状态：0=未锁定，1=已锁定 */
uint32_t g_lockout_start = 0;        /* 锁定开始时间（tick） */
uint32_t g_lockout_remain = 0;       /* 剩余锁定时间（秒） */

/* 实时锁状态监测 */
uint8_t g_last_lock_state = 0xFF;    /* 上次锁状态（0xFF=未初始化） */
uint32_t g_last_lock_check = 0;      /* 上次检查时间 */
#define LOCK_CHECK_INTERVAL  200     /* 锁状态检查间隔（ms） */

/* TCP远程控制相关 */
uint8_t g_tcp_connected = 0;         /* TCP连接状态 */
uint32_t g_last_tcp_check = 0;       /* 上次TCP检查时间 */

/* 菜单索引 */
uint8_t g_menu_idx = 0;

typedef enum {
    STATE_HOME,           /* 主界面（直接输入密码解锁） */
    STATE_MENU,           /* 菜单 */
    STATE_WIFI_MANAGE,    /* WiFi管理 */
    STATE_WIFI_SELECT,    /* WiFi选择 */
    STATE_WIFI_PWD,       /* WiFi密码输入 */
    STATE_VERIFY_PWD,     /* 验证旧密码 */
    STATE_CHANGE_PWD,     /* 修改开锁密码 */
    STATE_SYSTEM_INFO     /* 系统信息 */
} State_t;

State_t g_state = STATE_HOME;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void ShowHome(void);
void UpdateHomePwd(void);
void ShowMenu(void);
void UpdateMenuSelect(void);
void ShowWiFiManage(void);
void ShowWiFiList(void);
void UpdateWiFiListSelect(void);
void ShowWiFiPwdInput(void);
void UpdateWiFiPwd(void);
void ShowVerifyPwd(void);
void UpdateVerifyPwd(void);
void ShowChangePwd(void);
void UpdateChangePwd(void);
void ShowSystemInfo(void);
void DoUnlock(void);
void DoWiFiConnect(void);
void DoWiFiScan(void);
void LoadPassword(void);
void SavePassword(void);
void ShowLockout(void);
void UpdateLockoutTime(void);
uint8_t CheckLockout(void);
void CheckLockStateChange(void);
void TCP_Connect(void);
void TCP_SendStatus(void);
void TCP_CheckCommand(void);
void DoRemoteUnlock(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* 菜单项名称 */
const char* menu_items[MENU_ITEMS] = {
    "1.WiFi",
    "2.Change PWD",
    "3.System Info"
};

/*============================================================================
 * EEPROM密码存储函数
 *============================================================================*/

/* 从EEPROM加载密码 */
void LoadPassword(void)
{
    uint8_t flag;
    uint8_t pwd_buf[LOCK_PWD_LEN + 1];
    
    /* 读取初始化标志 */
    flag = AT24C02_ReadByte(EEPROM_ADDR_FLAG);
    
    if (flag == EEPROM_FLAG_INIT)
    {
        /* 已初始化，读取密码 */
        if (AT24C02_ReadBytes(EEPROM_ADDR_PWD, pwd_buf, LOCK_PWD_LEN) == 0)
        {
            pwd_buf[LOCK_PWD_LEN] = '\0';
            
            /* 验证密码有效性（全是数字） */
            uint8_t valid = 1;
            for (uint8_t i = 0; i < LOCK_PWD_LEN; i++)
            {
                if (pwd_buf[i] < '0' || pwd_buf[i] > '9')
                {
                    valid = 0;
                    break;
                }
            }
            
            if (valid)
            {
                strcpy(g_lock_pwd, (char*)pwd_buf);
                return;
            }
        }
    }
    
    /* 未初始化或读取失败，使用默认密码并保存 */
    strcpy(g_lock_pwd, DEFAULT_LOCK_PWD);
    SavePassword();
}

/* 保存密码到EEPROM */
void SavePassword(void)
{
    /* 写入初始化标志 */
    AT24C02_WriteByte(EEPROM_ADDR_FLAG, EEPROM_FLAG_INIT);
    
    /* 写入密码 */
    AT24C02_WriteBytes(EEPROM_ADDR_PWD, (uint8_t*)g_lock_pwd, LOCK_PWD_LEN);
}

/*============================================================================
 * 界面显示函数
 *============================================================================*/

/* 显示主界面 */
void ShowHome(void)
{
    uint8_t i;
    char buf[17] = "PWD:            ";
    OLED_Clear();
    OLED_ShowString(1, 1, g_wifi_connected ? "Smart Locker [W]" : "Smart Locker    ");
    OLED_ShowString(2, 1, Lock_IsLocked() ? "Status: Locked  " : "Status: Open    ");
    for (i = 0; i < g_input_len && i < 6; i++) buf[4 + i] = '*';
    OLED_ShowString(3, 1, buf);
    OLED_ShowString(4, 1, "C:Menu          ");
}

/* 局部刷新密码 */
void UpdateHomePwd(void)
{
    uint8_t i;
    char buf[17] = "PWD:            ";
    for (i = 0; i < g_input_len && i < 6; i++) buf[4 + i] = '*';
    OLED_ShowString(3, 1, buf);
}

/* 显示菜单 */
void ShowMenu(void)
{
    uint8_t i;
    OLED_Clear();
    OLED_ShowString(1, 1, "---- Menu ----  ");
    for (i = 0; i < MENU_ITEMS; i++)
    {
        OLED_ShowChar(i + 2, 1, (i == g_menu_idx) ? '>' : ' ');
        OLED_ShowString(i + 2, 2, (char*)menu_items[i]);
    }
}

/* 局部更新菜单选择 */
void UpdateMenuSelect(void)
{
    uint8_t i;
    for (i = 0; i < MENU_ITEMS; i++)
        OLED_ShowChar(i + 2, 1, (i == g_menu_idx) ? '>' : ' ');
}

/* 显示WiFi管理 */
void ShowWiFiManage(void)
{
    char ip[16] = "";
    OLED_Clear();
    OLED_ShowString(1, 1, "---- WiFi ----  ");
    OLED_ShowString(2, 1, g_wifi_connected ? "Status: Online  " : "Status: Offline ");
    if (g_wifi_connected && ESP8266_GetIP(ip) == ESP8266_EOK)
        OLED_ShowString(3, 1, ip);
    OLED_ShowString(4, 1, "#:Scan          ");
}

/* 显示WiFi列表 */
void ShowWiFiList(void)
{
    uint8_t i, start, len;
    char buf[17];
    
    OLED_Clear();
    if (g_wifi_count == 0)
    {
        OLED_ShowString(2, 1, "No WiFi Found   ");
        OLED_ShowString(4, 1, "#:Rescan        ");
        return;
    }
    
    start = (g_select_idx < 4) ? 0 : (g_select_idx - 3);
    for (i = 0; i < 4 && (start + i) < g_wifi_count; i++)
    {
        memset(buf, ' ', 16); buf[16] = '\0';
        buf[0] = ((start + i) == g_select_idx) ? '>' : ' ';
        len = strlen(g_ssid_list[start + i]);
        memcpy(&buf[1], g_ssid_list[start + i], (len > 15) ? 15 : len);
        OLED_ShowString(i + 1, 1, buf);
    }
}

/* 局部更新WiFi选择 */
void UpdateWiFiListSelect(void)
{
    uint8_t i, start;
    if (g_wifi_count == 0) return;
    start = (g_select_idx < 4) ? 0 : (g_select_idx - 3);
    for (i = 0; i < 4 && (start + i) < g_wifi_count; i++)
        OLED_ShowChar(i + 1, 1, ((start + i) == g_select_idx) ? '>' : ' ');
}

/* 显示WiFi密码输入 */
void ShowWiFiPwdInput(void)
{
    char buf[17];
    OLED_Clear();
    memset(buf, ' ', 16); buf[16] = '\0';
    strncpy(buf, g_ssid_list[g_select_idx], 16);
    OLED_ShowString(1, 1, buf);
    memset(buf, ' ', 16);
    memcpy(buf, "PWD:", 4);
    if (g_pwd_len > 0) 
    {
        uint8_t len = (g_pwd_len > 12) ? 12 : g_pwd_len;
        strncpy(&buf[4], g_password, len);
    }
    OLED_ShowString(2, 1, buf);
    OLED_ShowString(4, 1, "#:Connect       ");
}

/* 局部更新WiFi密码 */
void UpdateWiFiPwd(void)
{
    char buf[17];
    memset(buf, ' ', 16); buf[16] = '\0';
    memcpy(buf, "PWD:", 4);
    if (g_pwd_len > 0) 
    {
        uint8_t len = (g_pwd_len > 12) ? 12 : g_pwd_len;
        strncpy(&buf[4], g_password, len);
    }
    OLED_ShowString(2, 1, buf);
}

/* 显示修改密码 */
void ShowChangePwd(void)
{
    uint8_t i;
    char buf[17] = "New PWD:        ";
    OLED_Clear();
    OLED_ShowString(1, 1, "-- Change PWD --");
    for (i = 0; i < g_input_len && i < 6; i++) buf[8 + i] = '*';
    OLED_ShowString(2, 1, buf);
}

/* 局部更新修改密码 */
void UpdateChangePwd(void)
{
    uint8_t i;
    char buf[17] = "New PWD:        ";
    for (i = 0; i < g_input_len && i < 6; i++) buf[8 + i] = '*';
    OLED_ShowString(2, 1, buf);
}

/* 显示验证旧密码 */
void ShowVerifyPwd(void)
{
    uint8_t i;
    char buf[17] = "Old PWD:        ";
    OLED_Clear();
    OLED_ShowString(1, 1, "-- Change PWD --");
    for (i = 0; i < g_input_len && i < 6; i++) buf[8 + i] = '*';
    OLED_ShowString(2, 1, buf);
    OLED_ShowString(3, 1, "Verify first    ");
}

/* 局部更新验证旧密码 */
void UpdateVerifyPwd(void)
{
    uint8_t i;
    char buf[17] = "Old PWD:        ";
    for (i = 0; i < g_input_len && i < 6; i++) buf[8 + i] = '*';
    OLED_ShowString(2, 1, buf);
}

/* 显示系统信息 */
void ShowSystemInfo(void)
{
    char ip[16] = "";
    OLED_Clear();
    OLED_ShowString(1, 1, "-- System Info --");
    OLED_ShowString(2, 1, g_wifi_connected ? "WiFi: Online    " : "WiFi: Offline   ");
    OLED_ShowString(3, 1, Lock_IsLocked() ? "Lock: Locked    " : "Lock: Open      ");
    if (g_wifi_connected && ESP8266_GetIP(ip) == ESP8266_EOK)
        OLED_ShowString(4, 1, ip);
}

/*============================================================================
 * 密码锁定相关函数
 *============================================================================*/

/* 检查是否处于锁定状态，返回1=锁定中，0=未锁定 */
uint8_t CheckLockout(void)
{
    if (!g_pwd_locked) return 0;
    
    uint32_t elapsed = (HAL_GetTick() - g_lockout_start) / 1000;
    if (elapsed >= PWD_LOCKOUT_TIME)
    {
        /* 锁定时间已过，解除锁定 */
        g_pwd_locked = 0;
        g_pwd_error_cnt = 0;
        g_lockout_remain = 0;
        return 0;
    }
    
    g_lockout_remain = PWD_LOCKOUT_TIME - elapsed;
    return 1;
}

/* 显示锁定界面 */
void ShowLockout(void)
{
    char buf[17];
    OLED_Clear();
    OLED_ShowString(1, 1, "!! LOCKED !!    ");
    OLED_ShowString(2, 1, "Too many errors ");
    sprintf(buf, "Wait: %3lus      ", g_lockout_remain);
    OLED_ShowString(3, 1, buf);
    OLED_ShowString(4, 1, "                ");
}

/* 更新锁定倒计时显示 */
void UpdateLockoutTime(void)
{
    char buf[17];
    sprintf(buf, "Wait: %3lus      ", g_lockout_remain);
    OLED_ShowString(3, 1, buf);
}

/* 检查锁状态变化并实时更新显示 */
void CheckLockStateChange(void)
{
    uint8_t cur_state;
    
    /* 检查间隔 */
    if (HAL_GetTick() - g_last_lock_check < LOCK_CHECK_INTERVAL) return;
    g_last_lock_check = HAL_GetTick();
    
    cur_state = Lock_IsLocked();
    
    /* 状态无变化 */
    if (cur_state == g_last_lock_state) return;
    
    g_last_lock_state = cur_state;
    
    /* 根据当前页面局部刷新 */
    if (g_state == STATE_HOME && !g_pwd_locked)
    {
        OLED_ShowString(2, 1, cur_state ? "Status: Locked  " : "Status: Open    ");
    }
    else if (g_state == STATE_SYSTEM_INFO)
    {
        OLED_ShowString(3, 1, cur_state ? "Lock: Locked    " : "Lock: Open      ");
    }
}

/*============================================================================
 * 功能执行函数
 *============================================================================*/

/* 执行开锁 */
void DoUnlock(void)
{
    uint8_t ok = (strcmp(g_input_pwd, g_lock_pwd) == 0);
    OLED_Clear();
    
    if (ok)
    {
        /* 密码正确，清除错误计数 */
        g_pwd_error_cnt = 0;
        
        OLED_ShowString(2, 1, "Unlocking...    ");
        ok = (Lock_UnlockDefault() == LOCK_RESULT_SUCCESS);
        OLED_Clear();
        OLED_ShowString(2, 1, ok ? "Unlock Success! " : "Lock Error!     ");
        Feedback_Set(ok ? FB_SUCCESS : FB_FAIL);
    }
    else
    {
        /* 密码错误，增加错误计数 */
        g_pwd_error_cnt++;
        
        if (g_pwd_error_cnt >= PWD_ERROR_MAX)
        {
            /* 达到最大错误次数，触发锁定 */
            g_pwd_locked = 1;
            g_lockout_start = HAL_GetTick();
            g_lockout_remain = PWD_LOCKOUT_TIME;
            
            OLED_ShowString(1, 1, "!! WARNING !!   ");
            OLED_ShowString(2, 1, "System Locked!  ");
            OLED_ShowString(3, 1, "Wait 5 minutes  ");
            Feedback_Set(FB_ALARM);
            HAL_Delay(2000);
            Feedback_Stop();
        }
        else
        {
            char buf[17];
            sprintf(buf, "Error! (%d/%d)   ", g_pwd_error_cnt, PWD_ERROR_MAX);
            OLED_ShowString(2, 1, buf);
            Feedback_Set(FB_FAIL);
        }
    }
    
    HAL_Delay(1200);
    g_input_len = 0;
    g_input_pwd[0] = '\0';
}

/* WiFi扫描 */
void DoWiFiScan(void)
{
    g_wifi_count = g_select_idx = 0;
    memset(g_ssid_list, 0, sizeof(g_ssid_list));
    
    OLED_Clear();
    OLED_ShowString(2, 1, "Scanning...     ");
    
    ESP8266_HW_Reset();
    HAL_Delay(500);
    ESP8266_RxRestart();
    
    if (ESP8266_ATTest() != ESP8266_EOK)
    {
        OLED_ShowString(2, 1, "ESP8266 Error   ");
        HAL_Delay(1000);
        return;
    }
    
    ESP8266_ATEConfig(0);
    ESP8266_SetMode(1);
    HAL_Delay(200);
    ESP8266_RxRestart();
    ESP8266_ScanWiFi(g_ssid_list, &g_wifi_count);
}

/* WiFi连接 */
void DoWiFiConnect(void)
{
    char ip[16];
    uint8_t ok;
    
    OLED_Clear();
    OLED_ShowString(2, 1, "Connecting...   ");
    
    ok = (ESP8266_JoinAP(g_ssid_list[g_select_idx], g_password) == ESP8266_EOK);
    g_wifi_connected = ok;
    
    OLED_Clear();
    if (ok)
    {
        OLED_ShowString(1, 1, "Connected       ");
        if (ESP8266_GetIP(ip) == ESP8266_EOK)
            OLED_ShowString(2, 1, ip);
        HAL_Delay(1500);
        
        /* WiFi连接成功后尝试连接TCP服务器 */
        TCP_Connect();
    }
    else
    {
        OLED_ShowString(2, 1, "Failed          ");
        HAL_Delay(1000);
    }
    Feedback_Set(ok ? FB_SUCCESS : FB_FAIL);
}

/*============================================================================
 * TCP远程控制函数
 *============================================================================*/

/* 连接TCP服务器 */
void TCP_Connect(void)
{
    if (!g_wifi_connected) return;
    
    OLED_Clear();
    OLED_ShowString(2, 1, "TCP Connecting..");
    
    if (ESP8266_ConnectTCPServer(TCP_SERVER_IP, TCP_SERVER_PORT) == ESP8266_EOK)
    {
        g_tcp_connected = 1;
        OLED_ShowString(2, 1, "TCP Connected!  ");
        HAL_Delay(800);
        
        /* 连接成功后上报状态 */
        TCP_SendStatus();
    }
    else
    {
        g_tcp_connected = 0;
        OLED_ShowString(2, 1, "TCP Failed      ");
        HAL_Delay(800);
    }
}

/* 发送TCP数据 */
static void TCP_Send(char *data)
{
    char cmd[32];
    uint16_t len = strlen(data);
    
    sprintf(cmd, "AT+CIPSEND=%d", len);
    if (ESP8266_SendATCmd(cmd, ">", 1000) == ESP8266_EOK)
    {
        ESP8266_Printf("%s", data);
        HAL_Delay(100);
    }
}

/* 上报状态到服务器 */
void TCP_SendStatus(void)
{
    char buf[32];
    if (!g_tcp_connected) return;
    
    sprintf(buf, "STATUS:%s\n", Lock_IsLocked() ? "LOCKED" : "OPEN");
    TCP_Send(buf);
}

/* 执行远程开锁 */
void DoRemoteUnlock(void)
{
    uint8_t ok;
    
    /* 检查是否被锁定 */
    if (g_pwd_locked && CheckLockout())
    {
        TCP_Send("UNLOCK:LOCKED\n");
        return;
    }
    
    /* 执行开锁 */
    ok = (Lock_UnlockDefault() == LOCK_RESULT_SUCCESS);
    
    /* 上报结果 */
    TCP_Send(ok ? "UNLOCK:OK\n" : "UNLOCK:FAIL\n");
    
    /* 反馈 */
    Feedback_Set(ok ? FB_SUCCESS : FB_FAIL);
    
    /* 如果在主界面，刷新显示 */
    if (g_state == STATE_HOME && !g_pwd_locked)
    {
        OLED_ShowString(2, 1, ok ? "Remote Unlock!  " : "Unlock Failed!  ");
        HAL_Delay(1000);
        OLED_ShowString(2, 1, Lock_IsLocked() ? "Status: Locked  " : "Status: Open    ");
    }
}

/* 检查TCP接收的命令 */
void TCP_CheckCommand(void)
{
    uint8_t *rx_data;
    
    if (!g_tcp_connected) return;
    
    /* 检查间隔 */
    if (HAL_GetTick() - g_last_tcp_check < TCP_CHECK_INTERVAL) return;
    g_last_tcp_check = HAL_GetTick();
    
    /* 获取接收数据 */
    rx_data = ESP8266_GetRxFrame();
    if (rx_data == NULL) return;
    
    /* 检查是否有+IPD数据（TCP接收格式：+IPD,len:data） */
    char *p_ipd = strstr((char*)rx_data, "+IPD,");
    if (p_ipd != NULL)
    {
        char *p_data = strchr(p_ipd, ':');
        if (p_data != NULL)
        {
            p_data++;  /* 跳过冒号 */
            
            /* 解析命令 */
            if (strstr(p_data, "CMD:UNLOCK") != NULL)
            {
                DoRemoteUnlock();
            }
            else if (strstr(p_data, "CMD:STATUS") != NULL)
            {
                TCP_SendStatus();
            }
        }
        
        /* 清空接收缓冲区，准备接收下一条 */
        ESP8266_RxRestart();
    }
    
    /* 检查连接断开 */
    if (strstr((char*)rx_data, "CLOSED") != NULL)
    {
        g_tcp_connected = 0;
        ESP8266_RxRestart();
    }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  uint8_t key;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
  OLED_Init();
  KEY_Init();
  Feedback_Init();
  Lock_Init();
  HAL_Delay(100);
  OLED_Clear();
  
  OLED_ShowString(1, 1, "==Smart Locker==");
  OLED_ShowString(2, 1, "  Initializing..");
  
  /* 从EEPROM加载密码 */
  LoadPassword();
  
  /* 初始化ESP8266 */
  if (ESP8266_Init(115200) == ESP8266_EOK)
  {
      ESP8266_SetMode(1);
      
      /* 快速检查WiFi（2次） */
      for (uint8_t i = 0; i < 2 && !g_wifi_connected; i++)
      {
          if (ESP8266_GetJAP() == ESP8266_EOK) g_wifi_connected = 1;
          else HAL_Delay(1000);
      }
  }
  
  OLED_ShowString(3, 1, g_wifi_connected ? "WiFi: Online    " : "WiFi: Offline   ");
  HAL_Delay(1500);
  
  /* 如果WiFi已连接，尝试连接TCP服务器 */
  if (g_wifi_connected)
  {
      TCP_Connect();
  }
  
  /* 进入主界面 */
  g_state = STATE_HOME;
  g_input_len = 0;
  g_input_pwd[0] = '\0';
  g_last_lock_state = Lock_IsLocked();  /* 初始化锁状态 */
  ShowHome();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
      key = KEY_Scan();
      Feedback_Update();
      CheckLockStateChange();  /* 实时检测锁状态变化 */
      TCP_CheckCommand();      /* 检查远程控制命令 */
      
      /* 检查锁定状态 */
      if (g_pwd_locked)
      {
          static uint32_t last_update = 0;
          static uint8_t lockout_shown = 0;  /* 锁定界面是否已显示 */
          
          if (CheckLockout())
          {
              /* 仍在锁定中 */
              if (g_state == STATE_HOME)
              {
                  if (!lockout_shown)
                  {
                      /* 首次显示锁定界面 */
                      ShowLockout();
                      lockout_shown = 1;
                      last_update = HAL_GetTick();
                  }
                  else if (HAL_GetTick() - last_update >= 1000)
                  {
                      /* 每秒只更新倒计时 */
                      UpdateLockoutTime();
                      last_update = HAL_GetTick();
                  }
              }
              
              /* 锁定期间忽略所有按键（除了可以进入菜单查看系统信息） */
              if (key == KEY_C)
              {
                  g_menu_idx = 0;
                  g_state = STATE_MENU;
                  lockout_shown = 0;
                  ShowMenu();
              }
              else if (key == KEY_D && g_state != STATE_HOME)
              {
                  /* 从菜单返回锁定界面 */
                  g_state = STATE_HOME;
                  lockout_shown = 0;  /* 重新显示锁定界面 */
              }
              else if (g_state == STATE_MENU)
              {
                  /* 菜单中只允许查看系统信息 */
                  if (key == KEY_A && g_menu_idx > 0)
                  {
                      g_menu_idx--;
                      UpdateMenuSelect();
                  }
                  else if (key == KEY_B && g_menu_idx < MENU_ITEMS - 1)
                  {
                      g_menu_idx++;
                      UpdateMenuSelect();
                  }
                  else if (key == KEY_HASH && g_menu_idx == 2)
                  {
                      g_state = STATE_SYSTEM_INFO;
                      ShowSystemInfo();
                  }
              }
              else if (g_state == STATE_SYSTEM_INFO && key == KEY_D)
              {
                  g_state = STATE_MENU;
                  ShowMenu();
              }
              
              HAL_Delay(10);
              continue;
          }
          else
          {
              /* 锁定解除，返回主界面 */
              lockout_shown = 0;
              g_state = STATE_HOME;
              g_input_len = 0;
              g_input_pwd[0] = '\0';
              ShowHome();
          }
      }
      
      if (key != KEY_NONE)
      {
          Feedback_Set(FB_KEYPRESS);
          
          switch (g_state)
          {
              /*----------------------------------------------------------
               * 主界面：直接输入密码解锁
               * 0-9输入密码，#确认，*删除，C进入菜单
               *----------------------------------------------------------*/
              case STATE_HOME:
                  if (key >= '0' && key <= '9')
                  {
                      if (g_input_len < LOCK_PWD_LEN)
                      {
                          g_input_pwd[g_input_len++] = key;
                          g_input_pwd[g_input_len] = '\0';
                          UpdateHomePwd();  /* 局部刷新 */
                      }
                  }
                  else if (key == KEY_STAR)  /* *删除 */
                  {
                      if (g_input_len > 0)
                      {
                          g_input_len--;
                          g_input_pwd[g_input_len] = '\0';
                          UpdateHomePwd();
                      }
                  }
                  else if (key == KEY_HASH)  /* #确认解锁 */
                  {
                      if (g_input_len > 0)
                      {
                          DoUnlock();
                          ShowHome();
                      }
                  }
                  else if (key == KEY_C)  /* C进入菜单 */
                  {
                      g_menu_idx = 0;
                      g_state = STATE_MENU;
                      ShowMenu();
                  }
                  break;
              
              /*----------------------------------------------------------
               * 菜单：A上B下，#确认，D返回
               *----------------------------------------------------------*/
              case STATE_MENU:
                  if (key == KEY_A)  /* 上移 */
                  {
                      if (g_menu_idx > 0)
                      {
                          g_menu_idx--;
                          UpdateMenuSelect();  /* 局部刷新 */
                      }
                  }
                  else if (key == KEY_B)  /* 下移 */
                  {
                      if (g_menu_idx < MENU_ITEMS - 1)
                      {
                          g_menu_idx++;
                          UpdateMenuSelect();  /* 局部刷新 */
                      }
                  }
                  else if (key == KEY_HASH)  /* 确认 */
                  {
                      switch (g_menu_idx)
                      {
                          case 0:  /* WiFi */
                              g_state = STATE_WIFI_MANAGE;
                              ShowWiFiManage();
                              break;
                          case 1:  /* Change Password - 先验证旧密码 */
                              g_input_len = 0;
                              g_input_pwd[0] = '\0';
                              g_state = STATE_VERIFY_PWD;
                              ShowVerifyPwd();
                              break;
                          case 2:  /* System Info */
                              g_state = STATE_SYSTEM_INFO;
                              ShowSystemInfo();
                              break;
                      }
                  }
                  else if (key == KEY_D)  /* 返回主界面 */
                  {
                      g_input_len = 0;
                      g_input_pwd[0] = '\0';
                      g_state = STATE_HOME;
                      ShowHome();
                  }
                  break;
              
              /*----------------------------------------------------------
               * WiFi管理：#扫描，*断开，D返回
               *----------------------------------------------------------*/
              case STATE_WIFI_MANAGE:
                  if (key == KEY_HASH)  /* 扫描 */
                  {
                      DoWiFiScan();
                      g_state = STATE_WIFI_SELECT;
                      ShowWiFiList();
                  }
                  else if (key == KEY_STAR && g_wifi_connected)  /* 断开 */
                  {
                      OLED_Clear();
                      OLED_ShowString(2, 1, "Disconnecting...");
                      ESP8266_QuitAP();
                      g_wifi_connected = 0;
                      HAL_Delay(800);
                      ShowWiFiManage();
                  }
                  else if (key == KEY_D)  /* 返回 */
                  {
                      g_state = STATE_MENU;
                      ShowMenu();
                  }
                  break;
              
              /*----------------------------------------------------------
               * WiFi选择：A上B下，#选择，D返回
               *----------------------------------------------------------*/
              case STATE_WIFI_SELECT:
                  if (key == KEY_A)
                  {
                      if (g_select_idx > 0)
                      {
                          uint8_t old_start = (g_select_idx < 4) ? 0 : (g_select_idx - 3);
                          g_select_idx--;
                          uint8_t new_start = (g_select_idx < 4) ? 0 : (g_select_idx - 3);
                          if (old_start != new_start)
                              ShowWiFiList();  /* 需要滚动，重绘 */
                          else
                              UpdateWiFiListSelect();  /* 局部刷新 */
                      }
                  }
                  else if (key == KEY_B)
                  {
                      if (g_wifi_count > 0 && g_select_idx < g_wifi_count - 1)
                      {
                          uint8_t old_start = (g_select_idx < 4) ? 0 : (g_select_idx - 3);
                          g_select_idx++;
                          uint8_t new_start = (g_select_idx < 4) ? 0 : (g_select_idx - 3);
                          if (old_start != new_start)
                              ShowWiFiList();  /* 需要滚动，重绘 */
                          else
                              UpdateWiFiListSelect();  /* 局部刷新 */
                      }
                  }
                  else if (key == KEY_HASH)
                  {
                      if (g_wifi_count > 0)
                      {
                          g_pwd_len = 0;
                          g_password[0] = '\0';
                          g_state = STATE_WIFI_PWD;
                          ShowWiFiPwdInput();
                      }
                      else
                      {
                          DoWiFiScan();
                          ShowWiFiList();
                      }
                  }
                  else if (key == KEY_D)
                  {
                      g_state = STATE_WIFI_MANAGE;
                      ShowWiFiManage();
                  }
                  break;
              
              /*----------------------------------------------------------
               * WiFi密码输入：0-9输入，*删除，#连接，D返回
               *----------------------------------------------------------*/
              case STATE_WIFI_PWD:
                  if (key >= '0' && key <= '9')
                  {
                      if (g_pwd_len < MAX_PWD_LEN - 1)
                      {
                          g_password[g_pwd_len++] = key;
                          g_password[g_pwd_len] = '\0';
                          UpdateWiFiPwd();  /* 局部刷新 */
                      }
                  }
                  else if (key == KEY_STAR)
                  {
                      if (g_pwd_len > 0)
                      {
                          g_pwd_len--;
                          g_password[g_pwd_len] = '\0';
                          UpdateWiFiPwd();  /* 局部刷新 */
                      }
                  }
                  else if (key == KEY_HASH)
                  {
                      DoWiFiConnect();
                      g_state = STATE_WIFI_MANAGE;
                      ShowWiFiManage();
                  }
                  else if (key == KEY_D)
                  {
                      g_state = STATE_WIFI_SELECT;
                      ShowWiFiList();
                  }
                  break;
              
              /*----------------------------------------------------------
               * 验证旧密码：0-9输入，*删除，#验证，D返回
               *----------------------------------------------------------*/
              case STATE_VERIFY_PWD:
                  if (key >= '0' && key <= '9')
                  {
                      if (g_input_len < LOCK_PWD_LEN)
                      {
                          g_input_pwd[g_input_len++] = key;
                          g_input_pwd[g_input_len] = '\0';
                          UpdateVerifyPwd();
                      }
                  }
                  else if (key == KEY_STAR)
                  {
                      if (g_input_len > 0)
                      {
                          g_input_len--;
                          g_input_pwd[g_input_len] = '\0';
                          UpdateVerifyPwd();
                      }
                  }
                  else if (key == KEY_HASH)
                  {
                      if (strcmp(g_input_pwd, g_lock_pwd) == 0)
                      {
                          /* 验证成功，进入修改密码 */
                          g_input_len = 0;
                          g_input_pwd[0] = '\0';
                          g_state = STATE_CHANGE_PWD;
                          ShowChangePwd();
                      }
                      else
                      {
                          OLED_Clear();
                          OLED_ShowString(2, 1, "Wrong Password! ");
                          Feedback_Set(FB_FAIL);
                          HAL_Delay(1000);
                          g_input_len = 0;
                          g_input_pwd[0] = '\0';
                          ShowVerifyPwd();
                      }
                  }
                  else if (key == KEY_D)
                  {
                      g_state = STATE_MENU;
                      ShowMenu();
                  }
                  break;
              
              /*----------------------------------------------------------
               * 修改密码：0-9输入，*删除，#保存，D返回
               *----------------------------------------------------------*/
              case STATE_CHANGE_PWD:
                  if (key >= '0' && key <= '9')
                  {
                      if (g_input_len < LOCK_PWD_LEN)
                      {
                          g_input_pwd[g_input_len++] = key;
                          g_input_pwd[g_input_len] = '\0';
                          UpdateChangePwd();  /* 局部刷新 */
                      }
                  }
                  else if (key == KEY_STAR)
                  {
                      if (g_input_len > 0)
                      {
                          g_input_len--;
                          g_input_pwd[g_input_len] = '\0';
                          UpdateChangePwd();  /* 局部刷新 */
                      }
                  }
                  else if (key == KEY_HASH)
                  {
                      if (g_input_len == LOCK_PWD_LEN)
                      {
                          strcpy(g_lock_pwd, g_input_pwd);
                          SavePassword();
                          OLED_Clear();
                          OLED_ShowString(2, 1, "Saved           ");
                          Feedback_Set(FB_SUCCESS);
                          HAL_Delay(1000);
                          g_state = STATE_MENU;
                          ShowMenu();
                      }
                      else
                      {
                          OLED_Clear();
                          OLED_ShowString(2, 1, "Need 6 digits   ");
                          Feedback_Set(FB_FAIL);
                          HAL_Delay(1000);
                          ShowChangePwd();
                      }
                  }
                  else if (key == KEY_D)
                  {
                      g_state = STATE_MENU;
                      ShowMenu();
                  }
                  break;
              
              /*----------------------------------------------------------
               * 系统信息：D返回
               *----------------------------------------------------------*/
              case STATE_SYSTEM_INFO:
                  if (key == KEY_D)
                  {
                      g_state = STATE_MENU;
                      ShowMenu();
                  }
                  break;
              
              default:
                  g_input_len = 0;
                  g_input_pwd[0] = '\0';
                  g_state = STATE_HOME;
                  ShowHome();
                  break;
          }
      }
      
      HAL_Delay(10);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
