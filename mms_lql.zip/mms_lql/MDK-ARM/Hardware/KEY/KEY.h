#ifndef __KEY_H
#define __KEY_H

#include "main.h"

/* 键盘按键定义 */
#define KEY_NONE    0x00

/* 数字键 0-9 */
#define KEY_0       '0'
#define KEY_1       '1'
#define KEY_2       '2'
#define KEY_3       '3'
#define KEY_4       '4'
#define KEY_5       '5'
#define KEY_6       '6'
#define KEY_7       '7'
#define KEY_8       '8'
#define KEY_9       '9'

/* 功能键 */
#define KEY_A       'A'
#define KEY_B       'B'
#define KEY_C       'C'
#define KEY_D       'D'
#define KEY_STAR    '*'
#define KEY_HASH    '#'

/* 函数声明 */
void KEY_Init(void);
uint8_t KEY_Scan(void);

#endif
