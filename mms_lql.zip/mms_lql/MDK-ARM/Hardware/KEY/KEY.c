#include "KEY.h"

/* 4x4矩阵键盘键值映射表 */
static const uint8_t KeyMap[4][4] = {
    {KEY_1, KEY_2, KEY_3, KEY_A},
    {KEY_4, KEY_5, KEY_6, KEY_B},
    {KEY_7, KEY_8, KEY_9, KEY_C},
    {KEY_STAR, KEY_0, KEY_HASH, KEY_D}
};

/**
  * @brief  矩阵键盘初始化
  * @param  无
  * @retval 无
  */
void KEY_Init(void)
{
    HAL_GPIO_WritePin(GPIOA, KEY_ROW1_Pin|KEY_ROW2_Pin|KEY_ROW3_Pin|KEY_ROW4_Pin, GPIO_PIN_SET);
}

/**
  * @brief  读取当前按键（原始值，不消抖）
  * @retval 按键值
  */
static uint8_t KEY_ReadRaw(void)
{
    uint8_t key = KEY_NONE;
    
    for (uint8_t row = 0; row < 4; row++)
    {
        /* 设置当前行为低电平 */
        HAL_GPIO_WritePin(GPIOA, KEY_ROW1_Pin|KEY_ROW2_Pin|KEY_ROW3_Pin|KEY_ROW4_Pin, GPIO_PIN_SET);
        
        switch(row)
        {
            case 0: HAL_GPIO_WritePin(GPIOA, KEY_ROW1_Pin, GPIO_PIN_RESET); break;
            case 1: HAL_GPIO_WritePin(GPIOA, KEY_ROW2_Pin, GPIO_PIN_RESET); break;
            case 2: HAL_GPIO_WritePin(GPIOA, KEY_ROW3_Pin, GPIO_PIN_RESET); break;
            case 3: HAL_GPIO_WritePin(GPIOA, KEY_ROW4_Pin, GPIO_PIN_RESET); break;
        }
        
        /* 延时等待电平稳定 */
        for(volatile int i = 0; i < 100; i++);
        
        /* 检测各列 */
        for (uint8_t col = 0; col < 4; col++)
        {
            GPIO_PinState state = GPIO_PIN_SET;
            
            switch(col)
            {
                case 0: state = HAL_GPIO_ReadPin(GPIOA, KEY_COL1_Pin); break;
                case 1: state = HAL_GPIO_ReadPin(GPIOA, KEY_COL2_Pin); break;
                case 2: state = HAL_GPIO_ReadPin(GPIOA, KEY_COL3_Pin); break;
                case 3: state = HAL_GPIO_ReadPin(GPIOA, KEY_COL4_Pin); break;
            }
            
            if (state == GPIO_PIN_RESET)
            {
                key = KeyMap[row][col];
                break;
            }
        }
        
        if (key != KEY_NONE) break;
    }
    
    /* 恢复所有行为高电平 */
    HAL_GPIO_WritePin(GPIOA, KEY_ROW1_Pin|KEY_ROW2_Pin|KEY_ROW3_Pin|KEY_ROW4_Pin, GPIO_PIN_SET);
    
    return key;
}

/**
  * @brief  扫描矩阵键盘（带消抖，按下触发一次，必须释放后才能再次触发）
  * @param  无
  * @retval 按键值，如果没有按键则返回KEY_NONE
  */
uint8_t KEY_Scan(void)
{
    static uint8_t key_prev = KEY_NONE;  /* 上一次扫描的按键值 */
    static uint8_t key_stable = KEY_NONE; /* 稳定后的按键值 */
    static uint8_t key_cnt = 0;          /* 消抖计数 */
    static uint8_t key_flag = 0;         /* 0:可触发, 1:已触发等待释放 */
    
    uint8_t key_now = KEY_ReadRaw();
    uint8_t key_return = KEY_NONE;
    
    /* 消抖处理 */
    if (key_now == key_prev)
    {
        if (key_cnt < 5)
            key_cnt++;
        
        if (key_cnt >= 3)  /* 连续3次相同才认为稳定 */
            key_stable = key_now;
    }
    else
    {
        key_cnt = 0;
        key_prev = key_now;
    }
    
    /* 按键触发逻辑 */
    if (key_stable != KEY_NONE)
    {
        if (key_flag == 0)  /* 还没触发过 */
        {
            key_flag = 1;
            key_return = key_stable;  /* 返回按键值，只触发一次 */
        }
        /* key_flag == 1 时不返回，等待释放 */
    }
    else
    {
        key_flag = 0;  /* 按键释放，允许下次触发 */
    }
    
    return key_return;
}
