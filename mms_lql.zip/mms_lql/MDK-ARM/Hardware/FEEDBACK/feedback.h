/**
 ****************************************************************************************************
 * @file        feedback.h
 * @author      Your Name
 * @version     V1.0
 * @date        2025-01-XX
 * @brief       声光反馈模块驱动头文件（LED + BUZZER）
 ****************************************************************************************************
 */

#ifndef __FEEDBACK_H
#define __FEEDBACK_H

#include "stm32f1xx_hal.h"

/* LED GPIO定义 - PC13 */
#define LED_GPIO_PORT           GPIOC
#define LED_GPIO_PIN            GPIO_PIN_13
#define LED_GPIO_CLK_ENABLE()   do{ __HAL_RCC_GPIOC_CLK_ENABLE(); }while(0)

/* BUZZER GPIO定义 - PA12 */
#define BUZZER_GPIO_PORT           GPIOA
#define BUZZER_GPIO_PIN            GPIO_PIN_12
#define BUZZER_GPIO_CLK_ENABLE()   do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)

/* 控制宏 */
#define LED_ON()     HAL_GPIO_WritePin(LED_GPIO_PORT, LED_GPIO_PIN, GPIO_PIN_RESET)  /* 低电平点亮 */
#define LED_OFF()    HAL_GPIO_WritePin(LED_GPIO_PORT, LED_GPIO_PIN, GPIO_PIN_SET)    /* 高电平熄灭 */
#define LED_TOGGLE() HAL_GPIO_TogglePin(LED_GPIO_PORT, LED_GPIO_PIN)

/* 蜂鸣器控制 - 如果是低电平触发，请交换ON/OFF的电平 */
#define BUZZER_ON()  HAL_GPIO_WritePin(BUZZER_GPIO_PORT, BUZZER_GPIO_PIN, GPIO_PIN_SET)    /* 高电平触发 */
#define BUZZER_OFF() HAL_GPIO_WritePin(BUZZER_GPIO_PORT, BUZZER_GPIO_PIN, GPIO_PIN_RESET)  /* 低电平关闭 */

/* 如果你的蜂鸣器是低电平触发，取消下面的注释，注释掉上面的定义
#define BUZZER_ON()  HAL_GPIO_WritePin(BUZZER_GPIO_PORT, BUZZER_GPIO_PIN, GPIO_PIN_RESET)
#define BUZZER_OFF() HAL_GPIO_WritePin(BUZZER_GPIO_PORT, BUZZER_GPIO_PIN, GPIO_PIN_SET)
*/

/* 声光反馈模式定义 */
typedef enum {
    FB_SUCCESS = 0,     /* 成功：LED快闪 + 蜂鸣器短响1次 */
    FB_FAIL = 1,        /* 失败：LED慢闪 + 蜂鸣器短响2次 */
    FB_WARNING = 2,     /* 警告：LED慢闪 + 蜂鸣器间歇响 */
    FB_ALARM = 3,       /* 告警：LED常亮 + 蜂鸣器持续响 */
    FB_KEYPRESS = 4,    /* 按键：LED闪烁 + 蜂鸣器短响 */
    FB_OFF = 5          /* 关闭所有 */
} FeedbackMode_t;

/* 函数声明 */
void Feedback_Init(void);
void Feedback_Set(FeedbackMode_t mode);
void Feedback_Stop(void);
void Feedback_Update(void);      /* 在主循环中调用，更新闪烁和间歇响 */
void Buzzer_Beep(uint16_t time_ms, uint16_t freq);  /* 无源蜂鸣器发声 */
void Buzzer_KeyTone(void);       /* 按键音效 */

#endif /* __FEEDBACK_H */
