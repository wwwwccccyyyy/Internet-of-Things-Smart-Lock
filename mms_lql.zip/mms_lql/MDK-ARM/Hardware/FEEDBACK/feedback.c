/**
 ****************************************************************************************************
 * @file        feedback.c
 * @author      混的雲./
 * @brief       声光反馈模块驱动实现（LED + 无源蜂鸣器）
 ****************************************************************************************************
 */

#include "feedback.h"

/* 全局变量 */
static FeedbackMode_t g_fb_mode = FB_OFF;
static uint32_t g_fb_tick = 0;
static uint8_t g_fb_state = 0;

/**
 * @brief       微秒级延时（软件延时）
 * @param       us: 微秒数
 * @retval      无
 */
static void delay_us(uint32_t us)
{
    uint32_t i;
    for (i = 0; i < us * 8; i++)  /* 72MHz时钟，约8个循环=1us */
    {
        __NOP();
    }
}

/**
 * @brief       无源蜂鸣器发声（产生方波驱动）
 * @param       time_ms: 持续时间（毫秒）
 * @param       freq: 频率（Hz），推荐1000-4000Hz
 * @retval      无
 * @note        无源蜂鸣器需要方波驱动才能发声
 */
void Buzzer_Beep(uint16_t time_ms, uint16_t freq)
{
    uint32_t i;
    uint32_t cycles;
    uint32_t half_period_us;
    
    if (freq == 0) freq = 2000;  /* 默认2kHz */
    
    /* 计算半周期（微秒） */
    half_period_us = 500000 / freq;  /* 1000000 / (2 * freq) */
    
    /* 计算总周期数 */
    cycles = (uint32_t)time_ms * freq / 1000;
    
    /* 产生方波 */
    for (i = 0; i < cycles; i++)
    {
        BUZZER_ON();
        delay_us(half_period_us);
        BUZZER_OFF();
        delay_us(half_period_us);
    }
    
    /* 确保结束后关闭（多次写入确保稳定） */
    BUZZER_OFF();
    BUZZER_OFF();
}

/**
 * @brief       按键音效（短促的"滴"声）
 * @retval      无
 */
void Buzzer_KeyTone(void)
{
    Buzzer_Beep(30, 2500);  /* 30ms, 2.5kHz */
}

/**
 * @brief       声光反馈模块初始化
 * @retval      无
 */
void Feedback_Init(void)
{
    /* 确保蜂鸣器和LED初始状态关闭 */
    BUZZER_OFF();
    BUZZER_OFF();  /* 多次写入确保稳定 */
    LED_OFF();
    g_fb_mode = FB_OFF;
}

/**
 * @brief       设置声光反馈模式
 * @param       mode: 反馈模式
 * @retval      无
 */
void Feedback_Set(FeedbackMode_t mode)
{
    uint8_t i;
    
    g_fb_mode = mode;
    g_fb_tick = HAL_GetTick();
    g_fb_state = 0;
    
    switch (mode)
    {
        case FB_SUCCESS:
            /* 成功：蜂鸣器短响1次 + LED快闪3次 */
            Buzzer_Beep(100, 2000);  /* 100ms, 2kHz */
            for (i = 0; i < 3; i++)
            {
                LED_ON();
                HAL_Delay(100);
                LED_OFF();
                HAL_Delay(100);
            }
            g_fb_mode = FB_OFF;
            break;
            
        case FB_FAIL:
            /* 失败：蜂鸣器短响2次 + LED慢闪2次 */
            for (i = 0; i < 2; i++)
            {
                LED_ON();
                Buzzer_Beep(150, 1500);  /* 150ms, 1.5kHz（低沉） */
                LED_OFF();
                HAL_Delay(150);
            }
            g_fb_mode = FB_OFF;
            break;
            
        case FB_WARNING:
            /* 警告：需要Update配合实现间歇效果 */
            LED_ON();
            g_fb_state = 1;
            break;
            
        case FB_ALARM:
            /* 告警：需要Update配合实现持续响 */
            LED_ON();
            g_fb_state = 1;
            break;
            
        case FB_KEYPRESS:
            /* 按键：短促的"滴"声 */
            Buzzer_KeyTone();
            g_fb_mode = FB_OFF;
            break;
            
        case FB_OFF:
        default:
            LED_OFF();
            BUZZER_OFF();
            g_fb_mode = FB_OFF;
            break;
    }
}

/**
 * @brief       停止声光反馈
 * @retval      无
 */
void Feedback_Stop(void)
{
    LED_OFF();
    BUZZER_OFF();
    g_fb_mode = FB_OFF;
}

/**
 * @brief       更新声光反馈状态（用于警告和告警模式）
 * @note        需要在主循环中周期性调用
 * @retval      无
 */
void Feedback_Update(void)
{
    uint32_t current_tick = HAL_GetTick();
    
    switch (g_fb_mode)
    {
        case FB_WARNING:
            /* 警告：LED和蜂鸣器间歇（500ms响，500ms停） */
            if (current_tick - g_fb_tick >= 500)
            {
                if (g_fb_state == 0)
                {
                    LED_ON();
                    Buzzer_Beep(100, 2000);  /* 响100ms */
                    g_fb_state = 1;
                }
                else
                {
                    LED_OFF();
                    g_fb_state = 0;
                }
                g_fb_tick = current_tick;
            }
            break;
            
        case FB_ALARM:
            /* 告警：持续响（每100ms产生一次方波） */
            if (current_tick - g_fb_tick >= 100)
            {
                Buzzer_Beep(80, 2500);  /* 响80ms */
                g_fb_tick = current_tick;
            }
            break;
            
        default:
            break;
    }
}
