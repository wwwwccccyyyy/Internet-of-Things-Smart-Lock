/**
 ****************************************************************************************************
 * @file        esp8266.h
 * @author      混的云
 * @version     V1.0
 * @date        2025-01-16
 * @brief       ESP8266 WiFi模块驱动头文件
 ****************************************************************************************************
 */

#ifndef __ESP8266_H
#define __ESP8266_H

#include "main.h"
#include "usart.h"
#include <stdint.h>

/* 错误码定义 */
#define ESP8266_EOK         0   /* 无错误 */
#define ESP8266_ERROR       1   /* 通用错误 */
#define ESP8266_ETIMEOUT    2   /* 超时错误 */
#define ESP8266_EINVAL      3   /* 参数错误 */

/* GPIO定义 - PA11作为复位引脚 */
#define ESP8266_RST_GPIO_PORT           GPIOA
#define ESP8266_RST_GPIO_PIN            GPIO_PIN_11
#define ESP8266_RST_GPIO_CLK_ENABLE()   do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)

/* 复位控制宏 */
#define ESP8266_RST(x)  do { \
    if (x) HAL_GPIO_WritePin(ESP8266_RST_GPIO_PORT, ESP8266_RST_GPIO_PIN, GPIO_PIN_SET); \
    else HAL_GPIO_WritePin(ESP8266_RST_GPIO_PORT, ESP8266_RST_GPIO_PIN, GPIO_PIN_RESET); \
} while(0)

/* 缓冲区大小 */
#define ESP8266_RX_BUF_SIZE     512
#define ESP8266_TX_BUF_SIZE     128

/* WiFi扫描结果存储 */
#define WIFI_MAX_NUM            6       /* 最多存储6个WiFi */
#define WIFI_SSID_MAX_LEN       17      /* SSID最大长度16+1 */

/* 初始化和复位 */
uint8_t ESP8266_Init(uint32_t baudrate);
void ESP8266_HW_Reset(void);

/* AT指令基础功能 */
uint8_t ESP8266_SendATCmd(char *cmd, char *ack, uint32_t timeout);
uint8_t ESP8266_ATTest(void);
uint8_t ESP8266_SWReset(void);
uint8_t ESP8266_Restore(void);

/* 配置功能 */
uint8_t ESP8266_SetMode(uint8_t mode);      /* 1:Station, 2:AP, 3:AP+Station */
uint8_t ESP8266_ATEConfig(uint8_t cfg);     /* 0:关闭回显, 1:开启回显 */

/* WiFi功能 */
uint8_t ESP8266_JoinAP(char *ssid, char *pwd);
uint8_t ESP8266_GetIP(char *buf);

/* TCP功能 */
uint8_t ESP8266_ConnectTCPServer(char *server_ip, char *server_port);
uint8_t ESP8266_EnterTransparent(void);
void ESP8266_ExitTransparent(void);

/* WiFi扫描功能 */
uint8_t ESP8266_ScanWiFi(char ssid_list[][WIFI_SSID_MAX_LEN], uint8_t *count);
uint8_t ESP8266_GetJAP(void);
uint8_t ESP8266_GetConnectedSSID(char *ssid);
uint8_t ESP8266_QuitAP(void);

/* 数据收发辅助 */
void ESP8266_Printf(char *fmt, ...);
void ESP8266_RxRestart(void);
void ESP8266_RxContinue(void);
uint8_t* ESP8266_GetRxFrame(void);
uint16_t ESP8266_GetRxFrameLen(void);

/* UART中断处理（在stm32f1xx_it.c中调用） */
void ESP8266_UART_IRQHandler(void);

#endif /* __ESP8266_H */
