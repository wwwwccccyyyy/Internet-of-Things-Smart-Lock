/**
 ****************************************************************************************************
 * @file        esp8266.c
 * @author			混的雲./
 * @version     
 * @date        
 * @brief       ESP8266 WiFi模块驱动实现
 ****************************************************************************************************
 */

#include "esp8266.h"
#include <string.h>
#include <stdio.h>
#include <stdarg.h>

/* UART接收帧结构 */
typedef struct {
    uint8_t buf[ESP8266_RX_BUF_SIZE];   /* 接收缓冲区 */
    struct {
        uint16_t len    : 15;            /* 帧长度 [14:0] */
        uint16_t finsh  : 1;             /* 帧完成标志 [15] */
    } sta;
} esp8266_rx_frame_t;

/* 全局变量 */
static esp8266_rx_frame_t g_rx_frame = {0};
static uint8_t g_tx_buffer[ESP8266_TX_BUF_SIZE];

/* 外部UART句柄 */
extern UART_HandleTypeDef huart1;

/**
 * @brief       GPIO硬件初始化
 * @param       无
 * @retval      无
 */
static void esp8266_hw_init(void)
{
    GPIO_InitTypeDef gpio_init_struct;
    
    ESP8266_RST_GPIO_CLK_ENABLE();
    
    gpio_init_struct.Pin = ESP8266_RST_GPIO_PIN;
    gpio_init_struct.Mode = GPIO_MODE_OUTPUT_PP;
    gpio_init_struct.Pull = GPIO_NOPULL;
    gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(ESP8266_RST_GPIO_PORT, &gpio_init_struct);
    
    /* 初始化为高电平 */
    ESP8266_RST(1);
}

/**
 * @brief       ESP8266硬件复位
 * @param       无
 * @retval      无
 */
void ESP8266_HW_Reset(void)
{
    ESP8266_RST(0);
    HAL_Delay(100);
    ESP8266_RST(1);
    HAL_Delay(500);
}

/**
 * @brief       格式化输出到ESP8266
 * @param       fmt: 格式化字符串
 * @retval      无
 */
void ESP8266_Printf(char *fmt, ...)
{
    va_list ap;
    uint16_t len;
    
    va_start(ap, fmt);
    vsprintf((char *)g_tx_buffer, fmt, ap);
    va_end(ap);
    
    len = strlen((const char *)g_tx_buffer);
    HAL_UART_Transmit(&huart1, g_tx_buffer, len, HAL_MAX_DELAY);
}

/**
 * @brief       重启接收
 * @param       无
 * @retval      无
 */
void ESP8266_RxRestart(void)
{
    g_rx_frame.sta.len = 0;
    g_rx_frame.sta.finsh = 0;
}

/**
 * @brief       获取接收帧
 * @param       无
 * @retval      NULL: 未接收到完整帧
 *              其他: 接收帧缓冲区指针
 */
uint8_t* ESP8266_GetRxFrame(void)
{
    if (g_rx_frame.sta.finsh == 1)
    {
        g_rx_frame.buf[g_rx_frame.sta.len] = '\0';
        return g_rx_frame.buf;
    }
    else
    {
        return NULL;
    }
}

/**
 * @brief       获取接收帧长度
 * @param       无
 * @retval      0: 未接收到完整帧
 *              其他: 接收帧长度
 */
uint16_t ESP8266_GetRxFrameLen(void)
{
    if (g_rx_frame.sta.finsh == 1)
    {
        return g_rx_frame.sta.len;
    }
    else
    {
        return 0;
    }
}

/**
 * @brief       UART中断处理函数
 * @param       无
 * @retval      无
 * @note        在stm32f1xx_it.c的USART1_IRQHandler中调用
 */
void ESP8266_UART_IRQHandler(void)
{
    uint8_t tmp;
    uint32_t isrflags = huart1.Instance->SR;
    
    /* 处理溢出错误 */
    if ((isrflags & UART_FLAG_ORE) != RESET)
    {
        __HAL_UART_CLEAR_OREFLAG(&huart1);
        (void)huart1.Instance->SR;
        (void)huart1.Instance->DR;
    }
    
    /* 处理接收中断 */
    if ((isrflags & UART_FLAG_RXNE) != RESET)
    {
        tmp = (uint8_t)(huart1.Instance->DR & (uint8_t)0x00FF);
        
        if (g_rx_frame.sta.len < (ESP8266_RX_BUF_SIZE - 1))
        {
            g_rx_frame.buf[g_rx_frame.sta.len] = tmp;
            g_rx_frame.sta.len++;
        }
        else
        {
            /* 缓冲区溢出，重新开始 */
            g_rx_frame.sta.len = 0;
            g_rx_frame.buf[g_rx_frame.sta.len] = tmp;
            g_rx_frame.sta.len++;
        }
    }
    
    /* 处理空闲中断 */
    if ((isrflags & UART_FLAG_IDLE) != RESET)
    {
        /* 清除IDLE标志：读SR + 读DR */
        /* 如果RXNE置位，上面已经读取了DR，IDLE已被清除 */
        /* 如果RXNE未置位，需要在此清除IDLE */
        if ((isrflags & UART_FLAG_RXNE) == RESET)
        {
            __HAL_UART_CLEAR_IDLEFLAG(&huart1);
        }
        g_rx_frame.sta.finsh = 1;
    }
}

/**
 * @brief       重置完成标志（继续接收）
 * @param       无
 * @retval      无
 */
void ESP8266_RxContinue(void)
{
    g_rx_frame.sta.finsh = 0;
}

/**
 * @brief       发送AT指令
 * @param       cmd: AT指令字符串
 *              ack: 期望的应答字符串
 *              timeout: 超时时间(ms)
 * @retval      ESP8266_EOK: 成功
 *              ESP8266_ETIMEOUT: 超时
 */
uint8_t ESP8266_SendATCmd(char *cmd, char *ack, uint32_t timeout)
{
    uint8_t *ret = NULL;
    
    ESP8266_RxRestart();
    ESP8266_Printf("%s\r\n", cmd);
    
    if ((ack == NULL) || (timeout == 0))
    {
        return ESP8266_EOK;
    }
    
    while (timeout > 0)
    {
        ret = ESP8266_GetRxFrame();
        if (ret != NULL)
        {
            if (strstr((const char *)ret, ack) != NULL)
            {
                return ESP8266_EOK;
            }
            /* 不要清空缓冲区，继续等待更多数据 */
            ESP8266_RxContinue();
        }
        timeout--;
        HAL_Delay(1);
    }
    
    return ESP8266_ETIMEOUT;
}

/**
 * @brief       AT指令测试
 * @param       无
 * @retval      ESP8266_EOK: 测试成功
 *              ESP8266_ERROR: 测试失败
 */
uint8_t ESP8266_ATTest(void)
{
    uint8_t ret;
    uint8_t i;
    
    for (i = 0; i < 3; i++)
    {
        ret = ESP8266_SendATCmd("AT", "OK", 300);
        if (ret == ESP8266_EOK)
        {
            return ESP8266_EOK;
        }
        HAL_Delay(100);
    }
    
    return ESP8266_ERROR;
}

/**
 * @brief       软件复位
 * @param       无
 * @retval      ESP8266_EOK: 复位成功
 *              ESP8266_ERROR: 复位失败
 */
uint8_t ESP8266_SWReset(void)
{
    uint8_t ret;
    
    ret = ESP8266_SendATCmd("AT+RST", "OK", 500);
    if (ret == ESP8266_EOK)
    {
        HAL_Delay(1000);
        return ESP8266_EOK;
    }
    else
    {
        return ESP8266_ERROR;
    }
}

/**
 * @brief       恢复出厂设置
 * @param       无
 * @retval      ESP8266_EOK: 恢复成功
 *              ESP8266_ERROR: 恢复失败
 */
uint8_t ESP8266_Restore(void)
{
    uint8_t ret;
    
    ret = ESP8266_SendATCmd("AT+RESTORE", "ready", 3000);
    if (ret == ESP8266_EOK)
    {
        return ESP8266_EOK;
    }
    else
    {
        return ESP8266_ERROR;
    }
}

/**
 * @brief       设置工作模式
 * @param       mode: 1-Station模式, 2-AP模式, 3-AP+Station模式
 * @retval      ESP8266_EOK: 设置成功
 *              ESP8266_ERROR: 设置失败
 *              ESP8266_EINVAL: 参数错误
 */
uint8_t ESP8266_SetMode(uint8_t mode)
{
    uint8_t ret;
    
    switch (mode)
    {
        case 1:
            ret = ESP8266_SendATCmd("AT+CWMODE=1", "OK", 500);
            break;
        case 2:
            ret = ESP8266_SendATCmd("AT+CWMODE=2", "OK", 500);
            break;
        case 3:
            ret = ESP8266_SendATCmd("AT+CWMODE=3", "OK", 500);
            break;
        default:
            return ESP8266_EINVAL;
    }
    
    if (ret == ESP8266_EOK)
    {
        return ESP8266_EOK;
    }
    else
    {
        return ESP8266_ERROR;
    }
}

/**
 * @brief       配置回显
 * @param       cfg: 0-关闭回显, 1-开启回显
 * @retval      ESP8266_EOK: 配置成功
 *              ESP8266_ERROR: 配置失败
 *              ESP8266_EINVAL: 参数错误
 */
uint8_t ESP8266_ATEConfig(uint8_t cfg)
{
    uint8_t ret;
    
    switch (cfg)
    {
        case 0:
            ret = ESP8266_SendATCmd("ATE0", "OK", 500);
            break;
        case 1:
            ret = ESP8266_SendATCmd("ATE1", "OK", 500);
            break;
        default:
            return ESP8266_EINVAL;
    }
    
    if (ret == ESP8266_EOK)
    {
        return ESP8266_EOK;
    }
    else
    {
        return ESP8266_ERROR;
    }
}

/**
 * @brief       连接WiFi
 * @param       ssid: WiFi名称
 *              pwd: WiFi密码
 * @retval      ESP8266_EOK: 连接成功
 *              ESP8266_ERROR: 连接失败
 */
uint8_t ESP8266_JoinAP(char *ssid, char *pwd)
{
    uint8_t ret;
    char cmd[64];
    
    sprintf(cmd, "AT+CWJAP=\"%s\",\"%s\"", ssid, pwd);
    ret = ESP8266_SendATCmd(cmd, "WIFI GOT IP", 10000);
    if (ret == ESP8266_EOK)
    {
        return ESP8266_EOK;
    }
    else
    {
        return ESP8266_ERROR;
    }
}

/**
 * @brief       获取IP地址
 * @param       buf: IP地址缓冲区（至少16字节）
 * @retval      ESP8266_EOK: 获取成功
 *              ESP8266_ERROR: 获取失败
 */
uint8_t ESP8266_GetIP(char *buf)
{
    uint8_t ret;
    char *p_start;
    char *p_end;
    
    ret = ESP8266_SendATCmd("AT+CIFSR", "OK", 500);
    if (ret != ESP8266_EOK)
    {
        return ESP8266_ERROR;
    }
    
    p_start = strstr((const char *)ESP8266_GetRxFrame(), "\"");
    if (p_start != NULL)
    {
        p_end = strstr(p_start + 1, "\"");
        if (p_end != NULL)
        {
            *p_end = '\0';
            sprintf(buf, "%s", p_start + 1);
            return ESP8266_EOK;
        }
    }
    
    return ESP8266_ERROR;
}

/**
 * @brief       连接TCP服务器
 * @param       server_ip: 服务器IP地址
 *              server_port: 服务器端口号
 * @retval      ESP8266_EOK: 连接成功
 *              ESP8266_ERROR: 连接失败
 */
uint8_t ESP8266_ConnectTCPServer(char *server_ip, char *server_port)
{
    uint8_t ret;
    char cmd[64];
    
    sprintf(cmd, "AT+CIPSTART=\"TCP\",\"%s\",%s", server_ip, server_port);
    ret = ESP8266_SendATCmd(cmd, "CONNECT", 5000);
    if (ret == ESP8266_EOK)
    {
        return ESP8266_EOK;
    }
    else
    {
        return ESP8266_ERROR;
    }
}

/**
 * @brief       进入透传模式
 * @param       无
 * @retval      ESP8266_EOK: 进入成功
 *              ESP8266_ERROR: 进入失败
 */
uint8_t ESP8266_EnterTransparent(void)
{
    uint8_t ret;
    
    ret = ESP8266_SendATCmd("AT+CIPMODE=1", "OK", 500);
    ret += ESP8266_SendATCmd("AT+CIPSEND", ">", 500);
    if (ret == ESP8266_EOK)
    {
        return ESP8266_EOK;
    }
    else
    {
        return ESP8266_ERROR;
    }
}

/**
 * @brief       退出透传模式
 * @param       无
 * @retval      无
 */
void ESP8266_ExitTransparent(void)
{
    ESP8266_Printf("+++");
}

/**
 * @brief       断开WiFi连接
 * @param       无
 * @retval      ESP8266_EOK: 断开成功
 *              ESP8266_ERROR: 断开失败
 */
uint8_t ESP8266_QuitAP(void)
{
    uint8_t ret;
    
    ret = ESP8266_SendATCmd("AT+CWQAP", "OK", 1000);
    if (ret == ESP8266_EOK)
    {
        HAL_Delay(100);
        return ESP8266_EOK;
    }
    else
    {
        return ESP8266_ERROR;
    }
}

/**
 * @brief       扫描WiFi并直接解析存储SSID（实时解析方式，确保整行完整）
 * @param       ssid_list: 存储SSID的二维数组 [WIFI_MAX_NUM][WIFI_SSID_MAX_LEN]
 * @param       count: 返回找到的WiFi数量
 * @retval      ESP8266_EOK: 扫描成功
 *              ESP8266_ERROR: 扫描失败
 * @note        WiFi格式: +CWLAP:(3,"wcy",-42,"ca:cd:1d:a0:23:ca",6,-1,-1,4,4,7,0)\r\n
 */
uint8_t ESP8266_ScanWiFi(char ssid_list[][WIFI_SSID_MAX_LEN], uint8_t *count)
{
    uint32_t timeout;
    char *p_line_start, *p_line_end, *p_ssid_start, *p_ssid_end, *p_search;
    uint8_t wifi_count = 0;
    uint8_t len;
    uint16_t last_parse_pos = 0;
    uint8_t i;
    uint8_t retry;
    
    /* 清空输出参数 */
    *count = 0;
    for (i = 0; i < WIFI_MAX_NUM; i++)
    {
        ssid_list[i][0] = '\0';
    }
    
    /* 最多重试2次 */
    for (retry = 0; retry < 2; retry++)
    {
        /* 重置变量 */
        wifi_count = 0;
        last_parse_pos = 0;
        timeout = 12000;  /* 12秒超时 */
        
        /* 彻底清空接收缓冲区 */
        memset(g_rx_frame.buf, 0, ESP8266_RX_BUF_SIZE);
        g_rx_frame.sta.len = 0;
        g_rx_frame.sta.finsh = 0;
        
        /* 等待缓冲区稳定 */
        HAL_Delay(200);
        
        /* 发送扫描命令 */
        ESP8266_Printf("AT+CWLAP\r\n");
        
        /* 等待并实时解析数据 */
        while (timeout > 0)
        {
            /* 检查是否有新数据 */
            if (g_rx_frame.sta.len > last_parse_pos)
            {
                /* 添加字符串结束符 */
                g_rx_frame.buf[g_rx_frame.sta.len] = '\0';
                
                /* 从上次位置开始搜索 */
                p_search = (char *)&g_rx_frame.buf[last_parse_pos];
                
                /* 逐行解析，确保每行数据完整（以\r\n结尾） */
                while ((p_line_start = strstr(p_search, "+CWLAP:(")) != NULL && wifi_count < WIFI_MAX_NUM)
                {
                    /* 查找该行的结束位置\r\n */
                    p_line_end = strstr(p_line_start, "\r\n");
                    if (p_line_end == NULL)
                    {
                        /* 该行数据不完整，等待更多数据 */
                        break;
                    }
                    
                    /* 找到第一个引号（SSID开始前） */
                    p_ssid_start = strchr(p_line_start + 8, '"');
                    if (p_ssid_start == NULL || p_ssid_start > p_line_end)
                    {
                        /* 该行格式错误，跳过 */
                        p_search = p_line_end + 2;
                        last_parse_pos = (uint16_t)(p_search - (char *)g_rx_frame.buf);
                        continue;
                    }
                    p_ssid_start++;  /* 跳过引号，指向SSID开始 */
                    
                    /* 找到第二个引号（SSID结束） */
                    p_ssid_end = strchr(p_ssid_start, '"');
                    if (p_ssid_end == NULL || p_ssid_end > p_line_end)
                    {
                        /* 该行格式错误，跳过 */
                        p_search = p_line_end + 2;
                        last_parse_pos = (uint16_t)(p_search - (char *)g_rx_frame.buf);
                        continue;
                    }
                    
                    /* 计算SSID长度 */
                    len = p_ssid_end - p_ssid_start;
                    
                    /* 跳过空SSID */
                    if (len > 0)
                    {
                        if (len >= WIFI_SSID_MAX_LEN) len = WIFI_SSID_MAX_LEN - 1;
                        memcpy(ssid_list[wifi_count], p_ssid_start, len);
                        ssid_list[wifi_count][len] = '\0';
                        wifi_count++;
                    }
                    
                    /* 移动到下一行 */
                    p_search = p_line_end + 2;  /* 跳过\r\n */
                    last_parse_pos = (uint16_t)(p_search - (char *)g_rx_frame.buf);
                }
                
                /* 检查是否收满6个 */
                if (wifi_count >= WIFI_MAX_NUM)
                {
                    *count = wifi_count;
                    return ESP8266_EOK;
                }
                
                /* 检查是否收到OK（扫描结束） */
                if (strstr((char *)g_rx_frame.buf, "\r\nOK\r\n") != NULL)
                {
                    if (wifi_count > 0)
                    {
                        *count = wifi_count;
                        return ESP8266_EOK;
                    }
                    /* 收到OK但没找到WiFi，跳出等待重试 */
                    break;
                }
                
                /* 检查是否收到ERROR */
                if (strstr((char *)g_rx_frame.buf, "ERROR") != NULL)
                {
                    break;  /* 跳出等待重试 */
                }
            }
            
            timeout--;
            HAL_Delay(1);
        }
        
        /* 如果找到了WiFi就返回 */
        if (wifi_count > 0)
        {
            *count = wifi_count;
            return ESP8266_EOK;
        }
        
        /* 重试前等待 */
        HAL_Delay(500);
    }
    
    /* 重试后仍然失败 */
    *count = wifi_count;
    return (wifi_count > 0) ? ESP8266_EOK : ESP8266_ERROR;
}

/**
 * @brief       查询WiFi连接状态
 * @param       无
 * @retval      ESP8266_EOK: 已连接
 *              ESP8266_ERROR: 未连接
 */
uint8_t ESP8266_GetJAP(void)
{
    uint8_t ret;
    
    // AT+CWJAP? 如果已连接会返回 +CWJAP:"SSID"...
    // 如果未连接会返回 No AP
    ret = ESP8266_SendATCmd("AT+CWJAP?", "+CWJAP:", 2000);
    if (ret == ESP8266_EOK)
    {
        return ESP8266_EOK;
    }
    else
    {
        return ESP8266_ERROR;
    }
}

/**
 * @brief       获取当前连接的WiFi名称
 * @param       ssid: SSID缓冲区（至少33字节）
 * @retval      ESP8266_EOK: 获取成功
 *              ESP8266_ERROR: 获取失败
 */
uint8_t ESP8266_GetConnectedSSID(char *ssid)
{
    uint8_t ret;
    char *p_start;
    char *p_end;
    uint8_t len;
    
    ret = ESP8266_SendATCmd("AT+CWJAP?", "+CWJAP:", 2000);
    if (ret != ESP8266_EOK)
    {
        return ESP8266_ERROR;
    }
    
    // 解析返回的SSID: +CWJAP:"SSID","mac",...
    p_start = strstr((const char *)ESP8266_GetRxFrame(), "+CWJAP:\"");
    if (p_start != NULL)
    {
        p_start += 8;  // 跳过 +CWJAP:"
        p_end = strchr(p_start, '"');
        if (p_end != NULL)
        {
            len = p_end - p_start;
            if (len > 32) len = 32;  // 限制长度
            memcpy(ssid, p_start, len);
            ssid[len] = '\0';
            return ESP8266_EOK;
        }
    }
    
    return ESP8266_ERROR;
}

/**
 * @brief       ESP8266初始化
 * @param       baudrate: 波特率（必须为115200）
 * @retval      ESP8266_EOK: 初始化成功
 *              ESP8266_ERROR: 初始化失败
 */
uint8_t ESP8266_Init(uint32_t baudrate)
{
    /* 验证波特率 */
    if (baudrate != 115200)
    {
        return ESP8266_ERROR;
    }
    
    /* GPIO初始化 */
    esp8266_hw_init();
    
    /* 开启接收中断和空闲中断 */
    __HAL_UART_ENABLE_IT(&huart1, UART_IT_RXNE);
    __HAL_UART_ENABLE_IT(&huart1, UART_IT_IDLE);
    
    /* 硬件复位 */
    ESP8266_HW_Reset();
    
    /* 清空接收缓冲区 */
    ESP8266_RxRestart();
    
    /* AT指令测试 */
    if (ESP8266_ATTest() != ESP8266_EOK)
    {
        return ESP8266_ERROR;
    }
    
    return ESP8266_EOK;
}
