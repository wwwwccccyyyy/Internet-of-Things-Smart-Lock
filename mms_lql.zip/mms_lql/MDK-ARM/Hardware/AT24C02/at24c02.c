#include "at24c02.h"

/**
 * @brief  写入一个字节到EEPROM
 * @param  addr: 地址 (0-255)
 * @param  data: 要写入的数据
 * @retval 0: 成功, 1: 失败
 */
uint8_t AT24C02_WriteByte(uint8_t addr, uint8_t data)
{
    uint8_t buffer[2];
    buffer[0] = addr;
    buffer[1] = data;
    
    if(HAL_I2C_Master_Transmit(&hi2c1, AT24C02_ADDR, buffer, 2, AT24C02_TIMEOUT) != HAL_OK)
    {
        return 1;
    }
    
    // 等待写入完成
    HAL_Delay(5);
    return 0;
}

/**
 * @brief  从EEPROM读取一个字节
 * @param  addr: 地址 (0-255)
 * @retval 读取的数据
 */
uint8_t AT24C02_ReadByte(uint8_t addr)
{
    uint8_t data;
    
    // 发送地址
    if(HAL_I2C_Master_Transmit(&hi2c1, AT24C02_ADDR, &addr, 1, AT24C02_TIMEOUT) != HAL_OK)
    {
        return 0xFF;
    }
    
    // 读取数据
    if(HAL_I2C_Master_Receive(&hi2c1, AT24C02_ADDR, &data, 1, AT24C02_TIMEOUT) != HAL_OK)
    {
        return 0xFF;
    }
    
    return data;
}

/**
 * @brief  写入多个字节到EEPROM
 * @param  addr: 起始地址
 * @param  data: 数据指针
 * @param  len: 数据长度
 * @retval 0: 成功, 1: 失败
 */
uint8_t AT24C02_WriteBytes(uint8_t addr, uint8_t *data, uint16_t len)
{
    uint16_t i;
    uint8_t page_remain;
    
    page_remain = AT24C02_PAGE_SIZE - (addr % AT24C02_PAGE_SIZE);
    
    if(len <= page_remain)
    {
        // 数据在同一页内
        uint8_t buffer[AT24C02_PAGE_SIZE + 1];
        buffer[0] = addr;
        for(i = 0; i < len; i++)
        {
            buffer[i + 1] = data[i];
        }
        
        if(HAL_I2C_Master_Transmit(&hi2c1, AT24C02_ADDR, buffer, len + 1, AT24C02_TIMEOUT) != HAL_OK)
        {
            return 1;
        }
        HAL_Delay(5);
    }
    else
    {
        // 数据跨页
        len -= page_remain;
        
        // 写入第一页剩余部分
        uint8_t buffer[AT24C02_PAGE_SIZE + 1];
        buffer[0] = addr;
        for(i = 0; i < page_remain; i++)
        {
            buffer[i + 1] = data[i];
        }
        
        if(HAL_I2C_Master_Transmit(&hi2c1, AT24C02_ADDR, buffer, page_remain + 1, AT24C02_TIMEOUT) != HAL_OK)
        {
            return 1;
        }
        HAL_Delay(5);
        
        addr += page_remain;
        data += page_remain;
        
        // 写入完整页
        while(len >= AT24C02_PAGE_SIZE)
        {
            buffer[0] = addr;
            for(i = 0; i < AT24C02_PAGE_SIZE; i++)
            {
                buffer[i + 1] = data[i];
            }
            
            if(HAL_I2C_Master_Transmit(&hi2c1, AT24C02_ADDR, buffer, AT24C02_PAGE_SIZE + 1, AT24C02_TIMEOUT) != HAL_OK)
            {
                return 1;
            }
            HAL_Delay(5);
            
            addr += AT24C02_PAGE_SIZE;
            data += AT24C02_PAGE_SIZE;
            len -= AT24C02_PAGE_SIZE;
        }
        
        // 写入最后不足一页的数据
        if(len > 0)
        {
            buffer[0] = addr;
            for(i = 0; i < len; i++)
            {
                buffer[i + 1] = data[i];
            }
            
            if(HAL_I2C_Master_Transmit(&hi2c1, AT24C02_ADDR, buffer, len + 1, AT24C02_TIMEOUT) != HAL_OK)
            {
                return 1;
            }
            HAL_Delay(5);
        }
    }
    
    return 0;
}

/**
 * @brief  从EEPROM读取多个字节
 * @param  addr: 起始地址
 * @param  data: 数据指针
 * @param  len: 数据长度
 * @retval 0: 成功, 1: 失败
 */
uint8_t AT24C02_ReadBytes(uint8_t addr, uint8_t *data, uint16_t len)
{
    // 发送地址
    if(HAL_I2C_Master_Transmit(&hi2c1, AT24C02_ADDR, &addr, 1, AT24C02_TIMEOUT) != HAL_OK)
    {
        return 1;
    }
    
    // 读取数据
    if(HAL_I2C_Master_Receive(&hi2c1, AT24C02_ADDR, data, len, AT24C02_TIMEOUT) != HAL_OK)
    {
        return 1;
    }
    
    return 0;
}

/**
 * @brief  写入一页数据到EEPROM
 * @param  page: 页号 (0-31)
 * @param  data: 数据指针 (8字节)
 * @retval 0: 成功, 1: 失败
 */
uint8_t AT24C02_WritePage(uint8_t page, uint8_t *data)
{
    if(page >= (AT24C02_SIZE / AT24C02_PAGE_SIZE))
    {
        return 1;
    }
    
    uint8_t addr = page * AT24C02_PAGE_SIZE;
    return AT24C02_WriteBytes(addr, data, AT24C02_PAGE_SIZE);
}

/**
 * @brief  读取一页数据从EEPROM
 * @param  page: 页号 (0-31)
 * @param  data: 数据指针 (8字节)
 * @retval 0: 成功, 1: 失败
 */
uint8_t AT24C02_ReadPage(uint8_t page, uint8_t *data)
{
    if(page >= (AT24C02_SIZE / AT24C02_PAGE_SIZE))
    {
        return 1;
    }
    
    uint8_t addr = page * AT24C02_PAGE_SIZE;
    return AT24C02_ReadBytes(addr, data, AT24C02_PAGE_SIZE);
}

/**
 * @brief  清空EEPROM (全部写入0xFF)
 * @retval 0: 成功, 1: 失败
 */
uint8_t AT24C02_Clear(void)
{
    uint8_t data[AT24C02_PAGE_SIZE];
    uint8_t page;
    
    // 填充0x00
    for(uint8_t i = 0; i < AT24C02_PAGE_SIZE; i++)
    {
        data[i] = 0x00;
    }
    
    // 逐页清空
    for(page = 0; page < (AT24C02_SIZE / AT24C02_PAGE_SIZE); page++)
    {
        if(AT24C02_WritePage(page, data) != 0)
        {
            return 1;
        }
    }
    
    return 0;
}

/**
 * @brief  EEPROM测试函数
 * @retval 0: 成功, 1: 失败
 */
uint8_t AT24C02_Test(void)
{
    uint8_t write_data[8] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
    uint8_t read_data[8];
    
    // 写入测试数据
    if(AT24C02_WritePage(0, write_data) != 0)
    {
        return 1;
    }
    
    // 读取测试数据
    if(AT24C02_ReadPage(0, read_data) != 0)
    {
        return 1;
    }
    
    // 比较数据
    for(uint8_t i = 0; i < 8; i++)
    {
        if(write_data[i] != read_data[i])
        {
            return 1;
        }
    }
    
    return 0;
}
