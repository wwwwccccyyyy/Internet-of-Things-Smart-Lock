#ifndef __AT24C02_H
#define __AT24C02_H

#include "main.h"
#include "i2c.h"

// AT24C02 配置
#define AT24C02_ADDR        0xA0    // AT24C02设备地址 (1010000 << 1)
#define AT24C02_PAGE_SIZE   8       // 页大小
#define AT24C02_SIZE        256     // 总容量256字节
#define AT24C02_TIMEOUT     1000    // 超时时间

// 函数声明
uint8_t AT24C02_WriteByte(uint8_t addr, uint8_t data);
uint8_t AT24C02_ReadByte(uint8_t addr);
uint8_t AT24C02_WriteBytes(uint8_t addr, uint8_t *data, uint16_t len);
uint8_t AT24C02_ReadBytes(uint8_t addr, uint8_t *data, uint16_t len);
uint8_t AT24C02_WritePage(uint8_t page, uint8_t *data);
uint8_t AT24C02_ReadPage(uint8_t page, uint8_t *data);
uint8_t AT24C02_Clear(void);
uint8_t AT24C02_Test(void);

#endif /* __AT24C02_H */
