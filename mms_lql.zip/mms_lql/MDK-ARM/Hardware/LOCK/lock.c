#include "lock.h"

/**
 * @brief  电磁锁初始化
 * @note   GPIO已在gpio.c中初始化，这里只设置初始状态
 * @retval None
 */
void Lock_Init(void)
{
    /* GPIO已在MX_GPIO_Init()中初始化，这里只设置初始状态 */
    /* 初始化为低电平（不开锁） */
    HAL_GPIO_WritePin(LOCK_CTRL_GPIO_PORT, LOCK_CTRL_GPIO_PIN, GPIO_PIN_RESET);
}

/**
 * @brief  获取锁状态
 * @retval LOCK_STATE_LOCKED: 锁闭（短路，高电平）
 *         LOCK_STATE_UNLOCKED: 锁开（开路，低电平）
 */
LockState_t Lock_GetState(void)
{
    GPIO_PinState pin_state;
    
    pin_state = HAL_GPIO_ReadPin(LOCK_STATUS_GPIO_PORT, LOCK_STATUS_GPIO_PIN);
    
    if (pin_state == GPIO_PIN_SET)
    {
        return LOCK_STATE_LOCKED;   /* 高电平 = 短路 = 锁闭 */
    }
    else
    {
        return LOCK_STATE_UNLOCKED; /* 低电平 = 开路 = 锁开 */
    }
}

/**
 * @brief  开锁（带脉冲时间参数）
 * @param  pulse_time: 脉冲时间（200-1000ms）
 * @retval LOCK_RESULT_SUCCESS: 开锁成功
 *         LOCK_RESULT_TIMEOUT: 开锁超时
 *         LOCK_RESULT_FAILED: 开锁失败
 */
LockResult_t Lock_Unlock(uint16_t pulse_time)
{
    uint32_t start_time;
    LockState_t state;
    
    /* 限制脉冲时间范围 */
    if (pulse_time < LOCK_PULSE_TIME_MIN)
        pulse_time = LOCK_PULSE_TIME_MIN;
    if (pulse_time > LOCK_PULSE_TIME_MAX)
        pulse_time = LOCK_PULSE_TIME_MAX;
    
    /* 检查当前状态 */
    state = Lock_GetState();
    if (state == LOCK_STATE_UNLOCKED)
    {
        return LOCK_RESULT_SUCCESS;  /* 已经是开锁状态 */
    }
    
    /* 发送开锁脉冲（高电平） */
    HAL_GPIO_WritePin(LOCK_CTRL_GPIO_PORT, LOCK_CTRL_GPIO_PIN, GPIO_PIN_SET);
    HAL_Delay(pulse_time);
    HAL_GPIO_WritePin(LOCK_CTRL_GPIO_PORT, LOCK_CTRL_GPIO_PIN, GPIO_PIN_RESET);
    
    /* 等待锁状态改变，最多等待LOCK_UNLOCK_TIMEOUT */
    start_time = HAL_GetTick();
    while ((HAL_GetTick() - start_time) < LOCK_UNLOCK_TIMEOUT)
    {
        state = Lock_GetState();
        if (state == LOCK_STATE_UNLOCKED)
        {
            return LOCK_RESULT_SUCCESS;  /* 开锁成功 */
        }
        HAL_Delay(10);  /* 每10ms检查一次 */
    }
    
    /* 超时未开锁 */
    return LOCK_RESULT_TIMEOUT;
}

/**
 * @brief  开锁（使用默认脉冲时间）
 * @retval LOCK_RESULT_SUCCESS: 开锁成功
 *         LOCK_RESULT_TIMEOUT: 开锁超时
 *         LOCK_RESULT_FAILED: 开锁失败
 */
LockResult_t Lock_UnlockDefault(void)
{
    return Lock_Unlock(LOCK_PULSE_TIME_DEFAULT);
}

/**
 * @brief  判断是否处于锁闭状态
 * @retval 1: 锁闭, 0: 未锁闭
 */
uint8_t Lock_IsLocked(void)
{
    return (Lock_GetState() == LOCK_STATE_LOCKED) ? 1 : 0;
}

/**
 * @brief  判断是否处于开锁状态
 * @retval 1: 开锁, 0: 未开锁
 */
uint8_t Lock_IsUnlocked(void)
{
    return (Lock_GetState() == LOCK_STATE_UNLOCKED) ? 1 : 0;
}
