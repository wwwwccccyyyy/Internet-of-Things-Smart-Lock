#ifndef __LOCK_H
#define __LOCK_H

#include "main.h"

/* 锁控制引脚定义 - PC8 */
#define LOCK_CTRL_GPIO_PORT     GPIOC
#define LOCK_CTRL_GPIO_PIN      GPIO_PIN_8

/* 锁状态检测引脚定义 - PC9 */
#define LOCK_STATUS_GPIO_PORT   GPIOC
#define LOCK_STATUS_GPIO_PIN    GPIO_PIN_9

/* 锁状态枚举 */
typedef enum {
    LOCK_STATE_LOCKED = 1,      /* 锁闭状态（短路，高电平） */
    LOCK_STATE_UNLOCKED = 0     /* 锁开状态（开路，低电平） */
} LockState_t;

/* 开锁结果枚举 */
typedef enum {
    LOCK_RESULT_SUCCESS = 0,    /* 开锁成功 */
    LOCK_RESULT_TIMEOUT = 1,    /* 开锁超时 */
    LOCK_RESULT_FAILED = 2      /* 开锁失败 */
} LockResult_t;

/* 开锁脉冲时间配置（单位：ms） */
#define LOCK_PULSE_TIME_MIN     200     /* 最小脉冲时间 */
#define LOCK_PULSE_TIME_DEFAULT 5000     /* 默认脉冲时间 */
#define LOCK_PULSE_TIME_MAX     10000    /* 最大脉冲时间 */

/* 开锁超时时间（单位：ms） */
#define LOCK_UNLOCK_TIMEOUT     2000    /* 开锁超时时间 */

/* 函数声明 */
void Lock_Init(void);
LockState_t Lock_GetState(void);
LockResult_t Lock_Unlock(uint16_t pulse_time);
LockResult_t Lock_UnlockDefault(void);
uint8_t Lock_IsLocked(void);
uint8_t Lock_IsUnlocked(void);

#endif /* __LOCK_H */
